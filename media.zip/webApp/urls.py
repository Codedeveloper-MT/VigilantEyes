from django.urls import path
from . import views

urlpatterns = [
    # URL for the main dashboard view
    path('', views.dashboard, name='dashboard'),

    # URL to filter accident reports by date
    path('filter_accidents/', views.filter_accidents, name='filter_accidents'),

    # URL to filter crime reports by date
    path('filter_crimes/', views.filter_crimes, name='filter_crimes'),
    
    path('submit_incident/', views.submit_incident, name='submit_incident'),
    
    
    path('incidents/', views.incident_list, name='incident_list'),
]
