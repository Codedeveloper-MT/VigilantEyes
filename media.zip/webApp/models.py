from django.db import models

# Choices for incident types (if you plan to use this elsewhere)
INCIDENT_TYPES = [
    ('Accident', 'Accident'),
    ('Crime', 'Crime'),
]

# Model for Accident Reports

class AccidentReport(models.Model):
    # Define your fields here
    incident_type = models.CharField(max_length=20, choices=[('Accident', 'Accident'), ('Crime', 'Crime')])
    description = models.TextField(blank=True)
    location = models.CharField(max_length=255)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    video = models.FileField(upload_to='videos/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.incident_type} at {self.location} on {self.created_at}"


# Model for Crime Reports
class CrimeReport(models.Model):
    incident_type = models.CharField(max_length=50, default="Crime")  # Fixed value for Crime
    description = models.TextField(blank=True, null=True)  # Optional description
    location = models.CharField(max_length=255)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    video = models.FileField(upload_to='videos/', blank=True, null=True)
    date = models.DateField()  # Date of the crime report
    submitted_at = models.DateTimeField(auto_now_add=True)  # Timestamp for when the report was submitted

    def __str__(self):
        return f"Crime Report - {self.location} on {self.date}"
