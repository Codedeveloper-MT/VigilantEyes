from django.contrib import admin
from .models import AccidentReport, CrimeReport

admin.site.register(AccidentReport)
admin.site.register(CrimeReport)
